# Setup Instructions: 

Basically once you download the notebook that's all you need, other than two have the dataset as folder in the same folder/directory as the notebook so that my program can correctly read it in.

Assignment2.ipynb: Main program where all my working code blocks are
.gitignore: File mainly for version control on my github
README.md: setup instructions

(the report will be submitted as a seperate pdf)

The file structure should look something like this: 

Mode                 LastWriteTime         Length Name
----                 -------------         ------ ----
d-----         9/15/2025   9:39 AM                .ipynb_checkpoints
d-----         9/15/2025   1:39 PM                dataset
-a----         9/15/2025   1:41 PM            472 .gitignore
-a----         9/15/2025   9:06 AM         355238 A2 updated.pdf
-a----         9/15/2025  11:32 PM         175704 Assignment2.ipynb
-a----         9/15/2025   9:33 AM           1020 README.md